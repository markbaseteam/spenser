---
title:    "Como tomar notas ou capturar conteúdo da internet"  
author:   "Samej Spenser"  
date:     "July 10, 2022"  
update:   "July 11, 2022"  
tags:     [" take_notes capture_notes ReadItLater MarkDownload readwise smort glasp weava plugins "]  
aliases:  ["Samej Spenser", "como tomar notas no Obsidian", "captura de notas", "plugins do Obsidian", "ReadItLater", "MarkDownload",]  
abstract: "Os melhores métodos que eu utilizo para captura de notas no Obsidian através de plugins, serviços de terceiros e extensões de navegadores."  
link:
    - https://gist.github.com/4db4268c5d536c57472262d19b64f6ab  
    - https://gist.io/@SamejSpenser/4db4268c5d536c57472262d19b64f6ab  
    - https://hackmd.io/@SamejSpenser/HJQNkbYi9  
    - https://samej.com.br/XXXXXXXXXXXXXXXX  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
---

<!-- LINK EXTERNO PARA O CSS -->

<link rel="stylesheet" type="text/css" href="~/Dropbox/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="/home/samej/Dropbox/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="https://github.com/SamejSpenser/HPnews/blob/master/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="https://www.dropbox.com/s/7acsnogog4njf2o/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="../media/stylesheet-geral.css" />

<!-- LINK DO CSS NA PASTA DO EPSILON NO SMARTPHONE -->

<link rel="stylesheet" type="text/css" href="file:///storage/emulated/0/Epsilon/media/stylesheet-geral.css" />

<!-- COMO TOMAR NOTAS OU CAPTURAR CONTEÚDO DA INTERNET ~ CRIADO EM 2022/07/10 ~ ATUALIZADO EM 2022/07/11 -->

<center><span class="text-center meio" align="center">

## Como tomar notas ou capturar conteúdo da internet

</span></center>

<p>&nbsp;</p>

> [!info] Contexto  
> Os melhores métodos que eu utilizo para captura de notas no Obsidian através de plugins, serviços de terceiros e extensões de navegadores.

<p>&nbsp;</p>

### Introdução

No dia 10 de julho de 2022, o amigo “Batman” 🦇 fez esta solicitação:

<p>&nbsp;</p>

<span class="text-center meio" align="center"><script async src="https://telegram.org/js/telegram-widget.js?19" data-telegram-post="obsidianbr/2990" data-width="100%"></script></span>

<p>&nbsp;</p>

E eu enviei rapidamente três sugestões (como pode ser visto aí abaixo), ficando de lhe enviar mais detalhes quando voltasse pra casa.

<p>&nbsp;</p>

<span class="text-center meio" align="center"><script async src="https://telegram.org/js/telegram-widget.js?19" data-telegram-post="obsidianbr/2997" data-width="100%"></script></span>

<p>&nbsp;</p>

Cheguei em casa há alguns minutos e cá estou eu redigindo a resposta mais bem detalhada que fiquei de enviar.

<p>&nbsp;</p>

### 1\. ReadItLater

A descrição do #ReadItLater é curta e objetiva:

<p>&nbsp;</p>

<iframe width="100%" height="480" class="text-center meio" src="https://github.com/DominikPieper/obsidian-ReadItLater#readme" frameborder="0"></iframe>

<p>&nbsp;</p>

Este é o link para o [plugin ReadItLater](https://obsidian.md/plugins?search=readitlater). Com ele, você pode gerar um novo texto numa pasta predefinida para um link presente na área de transferência.

Aqui tem o template que eu utilizo no meu cofre:

```markdown
---
title:    "%articleTitle%"  
author:   "%authorName%"  
date:     "Month DD, 2022"  
update:   "Month DD, 2022"  
tags:     [" ReadItLater tag2 tag3 "]  
aliases:  ["%authorName%", "",]  
abstract: "DESCRIÇÃO AQUI."  
link:
    - %articleURL%
    - https://gist.github.com/SamejSpenser/XXXXXXXXXXXXXXXX  
    - https://gist.io/@SamejSpenser/XXXXXXXXXXXXXXXX  
    - https://hackmd.io/@SamejSpenser/XXXXXXXXXXXXXXXX  
    - https://samej.com.br/XXXXXXXXXXXXXXXX  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
---

<!-- LINK EXTERNO PARA O CSS -->

<link rel="stylesheet" type="text/css" href="~/Dropbox/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="/home/samej/Dropbox/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="https://github.com/SamejSpenser/HPnews/blob/master/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="https://www.dropbox.com/s/7acsnogog4njf2o/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="../media/stylesheet-geral.css" />

<!-- LINK DO CSS NA PASTA DO EPSILON NO SMARTPHONE -->

<link rel="stylesheet" type="text/css" href="file:///storage/emulated/0/Epsilon/media/stylesheet-geral.css" />

<!-- %articleTitle% ~ CRIADO EM 2022/MM/DD ~ ATUALIZADO EM 2022/MM/DD -->

<center><span class="text-center meio" align="center">

## %articleTitle%

</span></center>

<p>&nbsp;</p>

%articleContent%

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

- **Fonte:** _“[%articleTitle%](%articleURL%)”_ | ORIGEM  
- Month DD, 2022

<p>&nbsp;</p>

<!-- ###### tags: `ReadItLater`, `#`, `#`, -->

###### tags:

#ReadItLater, #, #, 

<p>&nbsp;</p>

```

<p>&nbsp;</p>

Uma inconveniência (por assim dizer) é que não encontrei um meio viável de inserir a data de criação/update e as tags correspondentes já na captura, tendo que inseri-las manualmente após a captura.

<p>&nbsp;</p>

### 2\. Conversor automático de HTML

Nas configurações do Obsidian, na aba “Editor”, lá embaixo, há uma opção que permite converter em Markdown o conteúdo previamente copiado para a área de transferência.

<span class="text-center meio" align="center">![](https://i.imgur.com/vamGgYk.png)</span>

Para utilizá-lo é bem simples: copie um trecho de um site (ou todo o conteúdo exibido num determinado link), crie um novo arquivo no Obsidian ou posicione o cursor no local adequado no arquivo já aberto e cole. É simples assim: “`Ctrl + C`” e “`Ctrl + V`”. Impossível ser mais fácil que isso! 😄

A inconveniência deste método é que não dá para colar utilizando um modelo/template pré-estabelecido, com metadados, datas, aliases, etc. Mas se o objetivo for apenas copiar um pequeno trecho para inserir num determinado arquivo, é simples e efetivo. 😉

<p>&nbsp;</p>

### 3\. MarkDownload

Dos três métodos aqui apresentados, o que eu mais faço uso no dia a dia é este, o **“[MarkDownload — Markdown Web Clipper](https://github.com/deathau/markdownload)”**.

O MarkDownload é uma extensão para os principais navegadores onde você pode definir em suas configurações diversos fatores para que se alinhem com a sua configuração preferida. Aqui no meu computador eu criei uma pasta específica dentro da pasta Downloads só para salvar os textos que eu quero capturar (você pode criar esta pasta _dentro do seu cofre_ do Obsidian).

Aqui tem meus modelos de front-matter e back-matter (respectivamente):

#### Front-matter

```markdown
---
title:    "{title} | {pageTitle}"  
author:   "{byline}"  
date:     "{date:LL}"  
update:   "{date:LL}"  
tags:     [" ReadItLater {keywords: #} "]  
aliases:  ["{byline}", "{keywords}",]  
abstract: "{excerpt}"  
links:
    - {baseURI}  
    - https://gist.github.com/SamejSpenser/XXXXXXXXXXXXXXXX  
    - https://gist.io/@SamejSpenser/XXXXXXXXXXXXXXXX  
    - https://hackmd.io/@SamejSpenser/XXXXXXXXXXXXXXXX  
    - https://samej.com.br/XXXXXXXXXXXXXXXX  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
---

<!-- LINK EXTERNO PARA O CSS -->

<link rel="stylesheet" type="text/css" href="~/Dropbox/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="/home/samej/Dropbox/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="https://github.com/SamejSpenser/HPnews/blob/master/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="https://www.dropbox.com/s/7acsnogog4njf2o/stylesheet-geral.css" />

<link rel="stylesheet" type="text/css" href="../media/stylesheet-geral.css" />

<!-- LINK DO CSS NA PASTA DO EPSILON NO SMARTPHONE -->

<link rel="stylesheet" type="text/css" href="file:///storage/emulated/0/Epsilon/media/stylesheet-geral.css" />

<!-- {title} ~ CRIADO EM {date:YYYY/MM/DD} ~ ATUALIZADO EM {date:YYYY/MM/DD} -->

## {title}

<p>&nbsp;</p>

> [!info]+ Contexto
> {excerpt}

<p>&nbsp;</p>


```

<p>&nbsp;</p>

#### Back-matter

```markdown

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

- **Fonte:** _“[{title}]({baseURI})”_ | {pageTitle}  
- {date:LL}

<p>&nbsp;</p>

###### tags:

#{keywords:#}, #{keywords}, #{keywords}, 

<p>&nbsp;</p>


```

<p>&nbsp;</p>

Tendo definido o front e back-matter, basta selecionar um trecho de um texto na internet ou clicar no ícone da extensão para que todo o texto seja copiado. Um pop-up será aberto para você conferir e, se desejar, fazer alguma alteração manual antes de salvar/fazer download do arquivo em formato `.md`. O front-matter será adicionado antes do conteúdo do texto e o back-matter será adicionado após o conteúdo do texto, gerando assim uma nota com metadados em YAML no início, o conteúdo desejado no meio e a citação da fonte no final do texto, para manter assim a referência correta de onde o conteúdo foi extraído.

É claro que é desejável que cada um de vocês adapte o front/back-matter para o seu padrão habitual de forma que as notas capturadas tenham sempre o mesmo “esqueleto”.

<p>&nbsp;</p>

> [!tip] Nota  
> Uma nota digna de ser mencionada é que se o site estiver mal configurado, se os metadados do site/texto estiverem ausentes ou mal formatados, a extensão pode deixar de reconhecer alguns dos parâmetros pré-configurados, como nome do autor, tags, data, etc. Daí a importância de revisar o pop-up antes de copiar/salvar.

<p>&nbsp;</p>

<span class="text-center meio" align="center">![](https://i.imgur.com/Jku1KHh.png)  
<small>Tela de configurações da extensão MarkDownload no LibreWolf (Firefox) • © Samej Spenser</small></span>

<p>&nbsp;</p>

As configurações são simples de serem definidas e você ainda pode salvar um backup (offline) das suas configurações em formato `.json`, de modo que após uma formatação ou instalação de um novo navegador basta importar esse backup para garantir que todas as suas configurações sejam utilizadas.

Caso você tenha habilitado algum sistema de sincronização no seu navegador (como o Sync no Firefox ou sua conta do Google no Chrome), é bem possível que suas configurações sejam mantidas. Por via das dúvidas, eu faço meu backup em formato `.json` no Dropbox e pCloud, pois, em matéria de backups, redundâncias nunca são demais! 😜

<p>&nbsp;</p>

### Conclusão

E você, quais outros meios ou métodos utiliza? Comente comigo aqui embaixo no campo de comentários e/ou lá no grupo [@ObsidianBR](https://t.me/obsidianbr/2990)!

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

<!-- IMAGEM CENTRALIZADA -->

<div align="center" class="text-center meio">
    <figure>
        <img width="80%" height="auto" alt="PRINTSCREEN: QR-Code para o grupo ObsidianBR no Telegram" src="https://i.imgur.com/R7jqNZt.png">
        <figcaption><small>Decodifique o QR-Code para ser direcionado(a) ao grupo no Telegram ou <a target="_blank" title="ObsidianBR no Telegram" href="https://t.me/obsidianbr/2990">clique/toque aqui</a>.</small></figcaption>
    </figure>
</div>

<p>&nbsp;</p>



