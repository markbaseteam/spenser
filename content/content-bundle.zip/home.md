---
title:    "Samej Spenser"  
author:   "Samej Spenser"  
date:     "June 4, 2022"  
update:   "June 16, 2022"  
tags:     [" #samej_spenser #samejspenser #pkm #markbase "]  
aliases:  ["Samej Spenser",]  
abstract: "Página inicial."  
link:
    - https://gist.github.com/XXXXXXX  
    - https://hackmd.io/@SamejSpenser/XXXXXXX  
    - https://samej.com.br/XXXXXXX  
    - https://spenser.markbase.xyz/pages/home  
    - https://spenser.markbase.xyz/home  
    - https://teletype.in/@samej/XXXXXXX  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
home:     true
---

<!-- LINK EXTERNO PARA O CSS -->

<link type="text/css" rel="stylesheet" href="/home/samej/Documentos/Draft/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link type="text/css" rel="stylesheet" href="https://github.com/SamejSpenser/HPnews/blob/master/stylesheet-geral.css" />

<link type="text/css" rel="stylesheet" href="https://www.dropbox.com/s/7acsnogog4njf2o/stylesheet-geral.css" />

<link type="text/css" rel="stylesheet" href="../media/stylesheet-geral.css" />

<!-- LINK DO CSS NA PASTA DO EPSILON NO SMARTPHONE -->

<link type="text/css" rel="stylesheet" href="file:///storage/emulated/0/Epsilon/media/stylesheet-geral.css" />

<!-- HOME | SPENSER.MARKBASE.XYZ ~ CRIADO/PUBLICADO EM 2022/06/04 ~ ATUALIZADO EM 2022/06/16 -->

<center>

# Samej Spenser

</center>

<!-- IMAGEM CENTRALIZADA -->

<div align="center" class="text-center meio">
    <figure>
        <img width="100%" height="auto" alt="FOTO: Samej Spenser, com jaqueta de couro e óculos escuros." src="https://i.imgur.com/GSPJTEI.png">
        <figcaption><small>Samej Spenser • © <a target="_blank" title="Raquel Reis Fotografia" href="https://raquelreis.com.br/">Raquel Reis</a></small></figcaption>
    </figure>
</div>

<!-- <span class="text-center meio" align="center">![FOTO: Samej Spenser, com jaqueta de couro e óculos escuros.](https://i.imgur.com/GSPJTEI.png)  
<small>Samej Spenser • © [Raquel Reis](https://raquelreis.com.br/ "Raquel Reis Fotografia")</small></span> -->

<p>&nbsp;</p>

Seja bem-vindo ao local em que eu, [[Articles/Personagens Hipnose/Samej Spenser|Samej Spenser]], manterei um registro do que venho estudando, aprendendo, conhecendo e testando em relação ao [[PKM]] \(_Personal Knowledge Management_\)[^1] e [[Zettelkasten]].[^2]

A maior parte desse aprendizado e testes se dão no [Obsidian.md](https://obsidian.md), que se propõe a ser seu segundo cérebro! 😉  
O Obsidian por si só já é excelente, mas sua extrema facilidade de personalização através dos plug-ins nativos e [da comunidade](https://obsidian.md/plugins) aumentam ainda mais suas capacidades.

<p>&nbsp;</p>

- Para saber mais sobre mim, você pode conferir este link: [samej.com.br/sobre](https://teletype.in/@samej/sobre).

- Para conferir minhas redes sociais, visite: [linktr.ee/samej](https://linktr.ee/samej).

- E se você é entusiasta do (ou ficou curioso quanto ao) Obsidian, saiba que temos um grupo (em português) no Telegram: [@ObsidianBR](https://t.me/ObsidianBR).

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

### Notas

<!-- [1] NOTA DE FIM -->

[^1]: A **Gestão do Conhecimento Pessoal** (PKM) é um processo de coleta de informações que uma pessoa usa para reunir, classificar, armazenar, pesquisar, recuperar e compartilhar conhecimento em suas atividades diárias (Grundspenkis 2007) e a maneira como esses processos suportam as atividades de trabalho (Wright 2005). É uma resposta à ideia de que os trabalhadores do conhecimento precisam ser responsáveis por seu próprio crescimento e aprendizado (Smedley 2009). É uma abordagem de baixo para cima para a gestão do conhecimento (GC) (Pollard 2008).  
    [Wikipédia](https://en.wikipedia.org/wiki/Personal_knowledge_management). 

<!-- [2] NOTA DE FIM -->

[^2]: O _**zettelkasten**_ (alemão: “slip box”, plural _**zettelkästen**_) é um sistema de anotações e gerenciamento de conhecimento pessoal usado em pesquisa e estudo. Variações do sistema de anotações são conhecidas pelo “índice de cartão” ou “arquivo de cartão de índice” em inglês e _fichier boîte_ (“caixa de arquivo”) em contextos franceses.  
    [Wikipédia](https://en.wikipedia.org/wiki/Zettelkasten). 

<p>&nbsp;</p>

