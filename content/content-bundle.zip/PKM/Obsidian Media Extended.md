---
title:    "Obsidian Media Extended: A melhor maneira de fazer anotações em vídeos"  
author:   "Samej Spenser"  
date:     "Maio 23, 2022"  
update:   "June 6, 2022"  
tags:     [" gestao_do_conhecimento pesquisa zettelkasten media_extended plugins obsidian bryan_jenks pkm samej_spenser take_notes "]  
aliases:  ["Media Extended", "Bryan Jenks", "gestão do conhecimento", "Zettelkasten", "Samej Spenser", "PKM", "Personal Knowledge Management", "A Importância de Tomar Notas",]  
abstract: "Excelente plugin para tomar notas de videoaulas, cursos online, podcasts e mídias diversas."  
links:
    - https://gist.github.com/5b3923577b6ffe098402409fb2a1cbdd  
    - https://spenser.markbase.xyz/pages/PKM/Obsidian%20Media%20Extended  
    - https://gist.io/@SamejSpenser/5b3923577b6ffe098402409fb2a1cbdd  
    - https://obsius.site/6i5e736m031z6l0d4n15
    - https://samej.com.br/media-extended  
    - https://telegra.ph/Obsidian-Media-Extended---A-melhor-maneira-de-fazer-anotações-em-vídeos-06-01  
    - https://teletype.in/@samej/media-extended  
    - https://www.bryanjenks.dev/blog/obsidian-media-extended-the-best-way-to-take-notes-on-videos-  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
telegraph_page_url: https://telegra.ph/Obsidian-Media-Extended---A-melhor-maneira-de-fazer-anotações-em-vídeos-06-01
telegraph_page_path: Obsidian-Media-Extended---A-melhor-maneira-de-fazer-anotações-em-vídeos-06-01
---

<!-- OBSIDIAN MEDIA EXTENDED: A MELHOR MANEIRA DE FAZER ANOTAÇÕES EM VÍDEOS ~ CRIADO/PUBLICADO EM 2022/05/23 ~ ATUALIZADO EM 2022/06/06 -->

<center>

## Obsidian Media Extended: <br />A melhor maneira de fazer anotações em vídeos

<p>&nbsp;</p>

<span class="meio" align="center"><iframe width="640" height="420" src="https://www.youtube.com/embed/GQXVWtNkeZw" title="Obsidian Media Extended: The Best Way To Take Notes On Videos 🎥️" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>  
<small><em>“<a target="_blank" title="Obsidian Media Extended: The Best Way To Take Notes On Videos 🎥️" href="https://www.youtube.com/watch?v=GQXVWtNkeZw">Obsidian Media Extended: The Best Way To Take Notes On Videos 🎥️</a>”</em> <br />©️ Bryan Jenks on YouTube</small></span>

</center>

<p>&nbsp;</p>

O [Media Extended](https://obsidian.md/plugins?search=media%20extended#) é a melhor [[A Importância de Tomar Notas|abordagem para anotações]] em arquivos de vídeo que você já viu. Isso torna super fácil obter o que sempre quis das notas de vídeo:

- Timestamps que saltam para esse ponto no vídeo;
- Timestamps sem esforço;
- Notas em markdown fáceis e criadas enquanto assiste a um vídeo.

Comecei com o YiNote no início de 2020 e mudei para a extensão do navegador memex quando oferecia uma experiência melhor e agora, finalmente, esse plugin já no sistema ecológico Obsidian agrega muito valor com uma funcionalidade tão simples.

Existem três principais pontos de crítica que tenho sobre o plugin que poderia ser trabalhado, mas em geral é essencial neste momento.

Crítica principal:

- O ponto final do cursor após a inserção do carimbo de data/hora sendo à esquerda versus à direita
- O foco do cursor após abrir o modal do plugin
- O foco do cursor após usar o modal do plugin
- A capacidade de apenas pressionar enter e fazer com que o modal abra a mídia após a colagem está ausente

Confira o plugin e deixe-me saber o que você pensa!

**Fonte:** [https://youtu.be/GQXVWtNkeZw](https://youtu.be/GQXVWtNkeZw)

- [00:00](https://youtu.be/GQXVWtNkeZw&t=0) - Welcome
- [00:37](https://youtu.be/GQXVWtNkeZw&t=37) - Intro
- [00:49](https://youtu.be/GQXVWtNkeZw&t=49) - My Introduction
- [02:47](https://youtu.be/GQXVWtNkeZw&t=167) - Support the channel
- [03:07](https://youtu.be/GQXVWtNkeZw&t=187) - Defining the problem
- [04:18](https://youtu.be/GQXVWtNkeZw&t=258) - How to Install/Set up
- [14:42](https://youtu.be/GQXVWtNkeZw&t=882) - Closing
- [15:12](https://youtu.be/GQXVWtNkeZw&t=912) - Outro

<!-- {{TIMESTAMP}}:  -->

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

- **Fonte:** tradução do texto _“[Obsidian Media Extended: The Best Way To Take Notes On Videos](https://www.bryanjenks.dev/blog/obsidian-media-extended-the-best-way-to-take-notes-on-videos-)”_ | BRYAN JENKS  
- May 31, 2022

<p>&nbsp;</p>

###### tags:

#gestao_do_conhecimento, #pesquisa, #zettelkasten #bryan_jenks, #plugin #media_extended, #pkm, #obsidian, #take_notes,

<p>&nbsp;</p>

