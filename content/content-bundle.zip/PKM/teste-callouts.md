---
title:    "Teste de Callouts"  
author:   "Samej Spenser"  
date:     "July 2, 2022"  
update:   "July 2, 2022"  
tags:     [" samej_spenser samejspenser pkm markbase callouts tomar_notas note_taking "]  
aliases:  ["Samej Spenser", "callouts", "tomar notas", "admonition",]  
abstract: "Página de testes de callouts no Markbase."  
link:
    - https://gist.github.com/XXXXXXX  
    - https://hackmd.io/@SamejSpenser/XXXXXXX  
    - https://samej.com.br/XXXXXXX  
    - https://spenser.markbase.xyz/pages/PKM/teste-callouts  
    - https://teletype.in/@samej/XXXXXXX  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
---

## Teste de Callouts

A partir da `v0.14.0`, o Obsidian suporta blocos de texto explicativo, — _<abbr title="Aka ou a.k.a. é a abreviação para “Also Known As”, uma expressão em inglês que significa “também conhecido como”, é usado para dar um significado ou nome mais conhecido a uma palavra ou pessoa.">a.k.a.</abbr>_ “Callouts” —, às vezes chamados “admonitions”. Os blocos de texto explicativo são escritos como um blockquote, inspirados na sintaxe de “alert” do Microsoft Docs.

Os textos explicativos também são suportados nativamente no [Obsidian Publish](https://help.obsidian.md/Obsidian+Publish/Introduction+to+Obsidian+Publish).

> [!note] Nota
> Por motivos de compatibilidade, se você também estiver usando o plug-in Admonitions, deverá atualizá-lo para pelo menos a `v8.0.0` para evitar problemas com o novo sistema de chamadas.

Use a seguinte sintaxe para denotar um bloco de texto explicativo: `> [!INFO]`.

```markdown
> [!INFO]
> Aqui está um bloco de texto explicativo.
> Ele suporta **markdown** e [[links internos|wikilinks]].
```

Vai aparecer assim:

> [!INFO]
> Aqui está um bloco de texto explicativo.  
> Ele suporta **markdown** e [wikilinks](https://help.obsidian.md/How+to/Internal+link).

<p>&nbsp;</p>

### Tipos

Por padrão, existem 12 tipos distintos de texto explicativo, cada um com vários aliases. Cada tipo vem com uma cor de fundo e um ícone diferentes.

Para usar esses estilos padrão, substitua `INFO` nos exemplos com qualquer um desses tipos. Qualquer tipo não reconhecido será padronizado para o tipo “note”, a menos que seja [personalizado](#Personalizações). O identificador de tipo não diferencia maiúsculas de minúsculas.

- Note
- Abstract, Summary, Tldr
- Info, Todo
- Tip, Hint, Important
- Success, Check, Done
- Question, Help, Faq
- Warning, Caution, Attention
- Failure, Fail, Missing
- Danger, Error
- Bug
- Example
- Quote, Cite

<p>&nbsp;</p>

> [!note] Note
> Magna pars studiorum, prodita quaerimus.

<p>&nbsp;</p>

> [!abstract]+ Abstract
> Cras mattis iudicium purus sit amet fermentum.

<p>&nbsp;</p>

> [!quote]- Quote
> Quisque ut dolor gravida, placerat libero vel, euismod.

<p>&nbsp;</p>

> [!cite] Cite
> A communi observantia non est recedendum.
> <p>&nbsp;</p>
> Ullamco laboris nisi ut aliquid ex ea commodi consequat.
> <p>&nbsp;</p>
> 
> > [!question]- Question
> Quo usque tandem abutere, Catilina, patientia nostra?
> 
> <p>&nbsp;</p>
> Curabitur est gravida et libero vitae dictum.

<p>&nbsp;</p>

### Título e corpo

Você pode definir o título do bloco de texto explicativo e também pode ter um texto explicativo sem conteúdo de corpo.

```markdown
> [!TIP] Callouts can have custom titles, which also supports **markdown**!
```

### Dobrando

Além disso, você pode criar um texto explicativo dobrável adicionando `+` (padrão expandido) ou `-` (padrão recolhido) após o bloco.

```markdown
> [!FAQ]- Are callouts foldable?
> Yes! In a foldable callout, the contents are hidden until it is expanded.
```

Vai aparecer como:

> [!FAQ]- Are callouts foldable?
> Yes! In a foldable callout, the contents are hidden until it is expanded.

<p>&nbsp;</p>

### Personalizações

Snippets e plug-ins também podem definir textos explicativos personalizados ou substituir as opções padrão. Os tipos de texto explicativo e os ícones são definidos em CSS, onde a cor é um `r, g, b` tupla e o ícone é o ID do ícone de qualquer ícone suportado internamente (como `lucide-info`). Alternativamente, você pode especificar um ícone SVG como uma string.

```css
.callout[data-callout="my-callout-type"] {
    --callout-color: 0, 0, 0;
    --callout-icon: icon-id;
    --callout-icon: '<svg>...custom svg...</svg>';
}
```

<p>&nbsp;</p>

