---
title:    "A Importância de Tomar Notas"  
author:   "Samej Spenser"  
date:     "June 6, 2022"  
update:   "June 26, 2022"  
tags:     [" samej_spenser samejspenser pkm markbase mortmer_adler tomar_notas note_taking "]  
aliases:  ["Samej Spenser", "Mortmer J. Adler", "tomar notas", "como ler um livro", "Obsidian Media Extended",]  
abstract: "Breve introdução ao hábito de tomar notas do que estuda, lê ou assiste."  
link:
    - https://gist.github.com/XXXXXXX  
    - https://hackmd.io/@SamejSpenser/XXXXXXX  
    - https://samej.com.br/XXXXXXX  
    - https://spenser.markbase.xyz/pages/PKM/A%20Import%C3%A2ncia%20de%20Tomar%20Notas  
    - https://teletype.in/@samej/XXXXXXX  
breaks:   false  
GA:       "UA-21920826-1"  
lang:     "pt_BR"  
---

<!-- LINK EXTERNO PARA O CSS -->

<link type="text/css" rel="stylesheet" href="/home/samej/Documentos/Draft/Gists-Privadas/CSS-geral/stylesheet-geral.css" />

<link type="text/css" rel="stylesheet" href="https://github.com/SamejSpenser/HPnews/blob/master/stylesheet-geral.css" />

<link type="text/css" rel="stylesheet" href="https://www.dropbox.com/s/7acsnogog4njf2o/stylesheet-geral.css" />

<link type="text/css" rel="stylesheet" href="../media/stylesheet-geral.css" />

<!-- LINK DO CSS NA PASTA DO EPSILON NO SMARTPHONE -->

<link type="text/css" rel="stylesheet" href="file:///storage/emulated/0/Epsilon/media/stylesheet-geral.css" />

<!-- A IMPORTÂNCIA DE TOMAR NOTAS | SPENSER.MARKBASE.XYZ ~ CRIADO/PUBLICADO EM 2022/06/06 ~ ATUALIZADO EM 2022/06/26 -->

<center>

## A Importância de Tomar Notas

</center>

<!-- IMAGEM CENTRALIZADA -->

<div align="center" class="text-center meio">
    <figure>
        <img width="100%" height="auto" alt="PRINTSCREEN: screenshot do obsidian, onde este texto foi redigido. Na coluna da esquerda, a tela de edição; na coluna da direita, a visualização da renderização do texto redigido." src="https://i.imgur.com/lUwTV4e.png">
        <figcaption><small>Printscreen da redação deste texto • © Samej Spenser</small></figcaption>
    </figure>
</div>

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

> [!quote] Mortmer J. Adler
> “Quando você compra um livro, você estabelece uma propriedade diretamente nele, assim como você faz com roupas ou móveis quando você compra e paga por eles. Mas o ato de compra é, na verdade, apenas o prelúdio da posse no caso de um livro. A posse total de um livro só vem quando você o torna parte de si mesmo, e a melhor maneira de se tornar parte dele — o que dá no mesmo — é escrevendo nele.
> 
> Por que marcar um livro é indispensável para lê-lo? Primeiro, ela o mantém acordado — não apenas consciente, mas bem desperto. Em segundo lugar, ler, se for ativo, é pensar, e o pensamento tende a se expressar em palavras, faladas ou escritas. A pessoa que diz que sabe o que pensa, mas não pode expressá-lo, geralmente não sabe o que pensa. Terceiro, escrever suas reações ajuda você a se lembrar dos pensamentos do autor.
> 
> Ler um livro deve ser uma conversa entre você e o autor. Presumivelmente, ele sabe mais sobre o assunto do que você; se não, você provavelmente não deveria se incomodar com o livro dele. Mas a compreensão é uma operação de mão dupla; o aluno tem que questionar a si mesmo e questionar o professor. Ele até tem que estar disposto a discutir com o professor, uma vez que ele entende o que o professor está dizendo. Marcar um livro é literalmente uma expressão de suas diferenças ou de seus acordos com o autor. É o maior respeito que você pode pagar a ele.”
> 
> — Trecho do livro _“Como Ler um Livro”_, de Mortmer J. Adler, 1940.

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

Tomando as palavras de Mortmer Adler e adaptando-as ao tempo hodierno, é indispensável que tomemos notas do que lemos, [[Obsidian Media Extended|assistimos]], estudamos e redigimos, que interliguemos os temas, assuntos e similaridades às notas já existentes de forma que se tornem “um centro nervoso”, onde você é estimulado a dar continuidade à sinapse para chegar até o fim da conexão e continuar irradiando por cada terminação desse complexo conjunto de nervos e intersecções nervosas.

Isso me remete a um tema que abordei lá no grupo [@ObsidianBR](https://t.me/obsidianbr/1210) no Telegram:

<p>&nbsp;</p>

<!-- MENSAGEM DE SAMEJ SPENSER NO TELEGRAM -->

<div align="center" class="text-center meio"><script async src="https://telegram.org/js/telegram-widget.js?19" data-telegram-post="obsidianbr/1210" data-width="90" data-userpic="true" data-dark="1"></script></div>

<p>&nbsp;</p>

<div align="center" class="text-center meio"><iframe width="560" height="315" src="https://www.youtube.com/embed/-3B8wohrowk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> <br /><small><em>“<a>O homem e a caixa do nada</a>”</em>, Pr. Cláudio Duarte • YouTube</small></div>

<p>&nbsp;</p>

<!-- MENSAGEM DE VOZ DE SAMEJ SPENSER NO TELEGRAM -->

<div align="center" class="text-center meio"><script async src="https://telegram.org/js/telegram-widget.js?19" data-telegram-post="obsidianbr/1211" data-width="90" data-userpic="true" data-dark="1"></script></div>

<!-- SEPARADOR -->

<p>&nbsp;</p>

<hr style="text-align: center; margin: auto;" width="30%" />

<p>&nbsp;</p>

Tanto no trecho de Adler, quanto na fala do Pr. Cláudio Duarte e na linha de raciocínio de Sherlock Holmes em seu diálogo com o Dr. Watson, podemos perceber que manter a interligação entre os textos, notas e trechos similares é imprescindível para que nosso aprendizado seja aprimorado e nossa retenção aumente devido à correlação entre um e outro.

<p>&nbsp;</p>

### Ferramentas

Num texto anterior, traduzi um pequeno texto do Bryan Jenks e embedei um vídeo onde ele apresenta o plugin do obsidian chamado “[Obsidian Media Extended](https://spenser.markbase.xyz/pages/PKM/Obsidian%20Media%20Extended)”, que facilita o processo de tomar notas dos vídeos que assiste.

Para quem não utiliza o Obsidian, uma alternativa é a extensão do Chrome “[Clarity Notes](https://www.claritynotes.io/)”, que permite tomar notas (em markdown) enquanto assiste vídeos no YouTube.

<!-- IMAGEM CENTRALIZADA -->

<div align="center" class="text-center meio">
    <figure>
        <img width="100%" height="auto" alt="PRINTSCREEN: screenshot do YouTube com o Clarity Notes aberto tomando notas." src="https://i.imgur.com/HRw3NOa.png">
        <figcaption><small><em>“<a target="_blank" title="#340 – A forma mais efetiva de estudar assistindo a palestras e vídeo-aulas no YouTube" href="https://atalho.substack.com/p/340-a-forma-mais-efetiva-de-estudar?r=b0ham&s=r&utm_campaign=post&utm_medium=web">#340 – A forma mais efetiva de estudar assistindo a palestras e vídeo-aulas no YouTube</a>”</em> • © <strong>atalho.xyz</strong></small></figcaption>
    </figure>
</div>

<p>&nbsp;</p>

E [aqui tem uma thread](https://threadreaderapp.com/thread/1524345934209073153.html) da [valeriana grande versao aplique ✨](https://twitter.com/del_valy) no Twitter, onde ela apresenta diversas extensões do Chrome para estudar.

<p>&nbsp;</p>

### Conclusão

Tomar notas vai muito além de só redigir alguns poucos tópicos, é preciso interligar as anotações, criar uma rede que abranja o que já foi anotado anteriormente e seja facilmente localizável e reconhecível para ser anexado às futuras notas.

E você, quais ferramentas e/ou métodos utiliza? Conte-me lá no grupo [@ObsidianBR](https://t.me/ObsidianBR) no Telegram! 😉

<p>&nbsp;</p>

<!-- IMAGEM CENTRALIZADA -->

<div align="center" class="text-center meio">
    <figure>
        <img width="100%" height="auto" alt="PRINTSCREEN: QR-Code para o grupo ObsidianBR no Telegram" src="https://i.imgur.com/R7jqNZt.png">
        <figcaption><small>Decodifique o QR-Code para ser direcionado(a) ao grupo no Telegram ou <a target="_blank" title="ObsidianBR no Telegram" href="https://t.me/ObsidianBR">clique/toque aqui</a>.</small></figcaption>
    </figure>
</div>

<p>&nbsp;</p>

